Facebook Hashtag Remover
========================

A Google Chrome extension to remove annoying hashtags from the Facebook news feed, user timelines, and comments.
